package Test;

import java.util.ArrayList;
import java.util.List;

public class Bibliotheque {
    public List<Document> doc = new ArrayList<Document> ();

    public void ajouterDocument(final Document p1) {
    }

    public List<Document> listerDocuments() {
        return doc;
    }

}
