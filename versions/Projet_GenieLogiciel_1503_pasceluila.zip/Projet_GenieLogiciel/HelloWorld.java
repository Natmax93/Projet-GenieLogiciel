import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HelloWorld {
   public static void main(String[] args) {
      // Création de la fenêtre
      JFrame frame = new JFrame("Hello World");

      // Création de l'étiquette avec le texte "Hello World"
      JLabel label = new JLabel("Hello World");

      // Ajout de l'étiquette à un panneau
      JPanel panel = new JPanel();
      panel.add(label);

      // Création du bouton "Fermer"
      JButton closeButton = new JButton("Fermer");

      // Ajout d'un gestionnaire d'événements pour le clic sur le bouton "Fermer"
      closeButton.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            // Fermeture de la fenêtre
            frame.dispose();
         }
      });

      // Ajout du bouton à un autre panneau
      JPanel buttonPanel = new JPanel();
      buttonPanel.add(closeButton);

      // Ajout des deux panneaux à la fenêtre
      frame.getContentPane().add(panel);
      frame.getContentPane().add(buttonPanel, "South");

      // Affichage de la fenêtre
      frame.pack();
      frame.setVisible(true);
   }
}
