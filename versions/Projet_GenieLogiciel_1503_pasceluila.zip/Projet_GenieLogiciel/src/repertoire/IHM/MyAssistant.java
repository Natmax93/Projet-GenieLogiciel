package repertoire.IHM;

import repertoire.BackEnd.*;

public class MyAssistant {
    public static void main(String[] args) {
        UIRepertoire ihm = new UIRepertoire();
    }

}
