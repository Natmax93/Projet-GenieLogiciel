package Test;


public class Document {
    public int id;

    public String titre;

    private int etat;

    public void definirEtat(final int e) {
    }

}
