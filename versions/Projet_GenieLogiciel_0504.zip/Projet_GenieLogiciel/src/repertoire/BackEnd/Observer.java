package repertoire.BackEnd;

import javax.swing.JLabel;

public class Observer extends JLabel {
    public void update() {
    }

}
