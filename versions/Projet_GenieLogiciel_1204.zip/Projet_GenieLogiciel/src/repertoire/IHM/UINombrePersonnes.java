package repertoire.IHM;

import repertoire.BackEnd.*;
import repertoire.BackEnd.Observer;
import repertoire.BackEnd.Repertoire;

public class UINombrePersonnes extends Observer {
    public Repertoire repertoire;

    public void update() {
        System.out.println("On update UINombrePersonnes");
        if (repertoire != null) {
            setText("Nombres personnes : " + repertoire.listerPersonnes().length);
        }
    }

    public UINombrePersonnes() {
        super();
        setText("Nombres personnes");
    }

    public void setRepertoire(Repertoire repertoire) {
        this.repertoire = repertoire;
    }

}
