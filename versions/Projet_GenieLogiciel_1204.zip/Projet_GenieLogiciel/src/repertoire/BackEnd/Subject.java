package repertoire.BackEnd;

import java.util.ArrayList;
import java.util.List;

public class Subject {
    public List<Observer> observers = new ArrayList<Observer> ();

    public void attach(final Observer o) {
        observers.add(o);
    }

    public void detach(final Observer o) {
        observers.remove(o);
    }

    public void notifier() {
        for (Observer o : this.observers){
            o.update();
        }
    }

}
