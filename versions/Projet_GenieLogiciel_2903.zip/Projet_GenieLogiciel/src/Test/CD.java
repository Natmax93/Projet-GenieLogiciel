package Test;


public class CD extends Document {
    public String cddb;

}
